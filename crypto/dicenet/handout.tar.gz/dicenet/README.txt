The code in this challenge is largely taken from
  https://github.com/GaloisInc/garbled-neural-network-experiments

This challenge is not about an implementation-level bug (but who knows, maybe
there is one). Instead, you should focus on the content in these papers:
- https://ia.cr/2016/969
- https://ia.cr/2019/338

If you're actively working on this, don't hesitate to message me on Discord.
Depending on where people are at, I will consider releasing a hint. And if
you've solved the challenge, I'd also love to talk about it!
